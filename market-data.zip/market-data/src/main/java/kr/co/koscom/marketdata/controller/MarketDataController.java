package kr.co.koscom.marketdata.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.co.koscom.marketdata.api.MarketDataApiCaller;
import kr.co.koscom.marketdata.model.History;
import kr.co.koscom.marketdata.model.HistoryList;
import kr.co.koscom.marketdata.model.Issue;
import kr.co.koscom.marketdata.model.IssueList;
import kr.co.koscom.marketdata.service.MarketDataService;

@Controller
public class MarketDataController {
	
	@Autowired
	private MarketDataApiCaller marketDataApiCaller;
	
	@Autowired
	private MarketDataService marketDataService;
	
    @RequestMapping(path = "/greeting")
    public @ResponseBody String greeting() {
        return "Welcome to burning day~ (a.k.a HELLo)";
    }
    
    @RequestMapping(path = "/list")
    public @ResponseBody String list() {
    	
    	String retStr = "";
    	
    	// 주식 종목 리스트 호출
    	String marketCode = "kospi";
    	IssueList issueList = marketDataService.getList(marketCode);
    	
    	// 종목별 히스토리 호출
    	ArrayList<HistoryList> historyInfoList = marketDataService.getHistoryInfoList(marketCode, issueList);
    	
    	//// test code
//    	if(historyInfoList != null) {
//    		HistoryList historyInfo = historyInfoList.get(1);
//    		if(historyInfo != null) {
//    			retStr += "이름 : " + historyInfo.getIsuKorNm();
//    			
//    			for(History history : historyInfo.getHisLists()) {
//    				if(history != null) {
//        				String opnPrc = history.getOpnprc();
//        				String trdPrc = history.getTrdPrc();
//        				
//        				retStr += opnPrc + " - " + trdPrc + "\n"; 
//        			}
//    			}
//    		}
//		}
    	////

    	
    	
    	// 추천 종목 선정
    	ArrayList<Issue> recommendIssues = marketDataService.getRecommendIssues(historyInfoList);
    	
    	for(Issue issue : recommendIssues) {
    		retStr += issue.getIsuSrtCd() + "-" + issue.getIsuKorNm() + " ";
    	}
    	
    	
    	
    	
    	return retStr;
    }

}
