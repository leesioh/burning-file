package kr.co.koscom.marketdata.model;

import java.io.Serializable;

public class MasterInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8231010009163652264L;

	private String isuKorAbbrv;

	public String getIsuKorAbbrv() {
		return isuKorAbbrv;
	}

	public void setIsuKorAbbrv(String isuKorAbbrv) {
		this.isuKorAbbrv = isuKorAbbrv;
	}
	
}