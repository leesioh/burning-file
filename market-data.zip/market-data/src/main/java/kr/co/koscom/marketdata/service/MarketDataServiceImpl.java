package kr.co.koscom.marketdata.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.koscom.marketdata.api.MarketDataApiCaller;
import kr.co.koscom.marketdata.model.HistoryList;
import kr.co.koscom.marketdata.model.Issue;
import kr.co.koscom.marketdata.model.IssueList;

@Service
public class MarketDataServiceImpl implements MarketDataService{

	@Autowired
	private MarketDataApiCaller marketDataApiCaller;
	
	@Override
	public IssueList getList(String marketCode) {

		return marketDataApiCaller.getList(marketCode);
	}

	@Override
	public ArrayList<HistoryList> getHistoryInfoList(String marketCode, IssueList issueList) {

		Issue[] arrIssue = issueList.getIsuLists();
		ArrayList<HistoryList> historyInfoList = new ArrayList<HistoryList>();
    	
		String trnsmCycleTpCd = "M";
		String inqStrtDd = "20170101";
		String inqEndDd = "20171231";
		String reqCnt = "20";
		
		for(int i=0; i<arrIssue.length; i++) {
			Issue issue = arrIssue[i];
			String isuSrtCd = issue.getIsuSrtCd();
					
			HistoryList historyList = marketDataApiCaller.getIssueHistory(marketCode, isuSrtCd, trnsmCycleTpCd, inqStrtDd, inqEndDd, reqCnt);
			historyList.setIsuCd(issue.getIsuCd());
			historyList.setIsuKorAbbr(issue.getIsuKorAbbr());
			historyList.setIsuKorNm(issue.getIsuKorNm());
			historyList.setIsuSrtCd(issue.getIsuSrtCd());
			historyInfoList.add(historyList);
			
			// 호출 횟수 제한
			if(i == 50) {
				break;
			}
		}
		
		
		return historyInfoList;
	}

	@Override
	public ArrayList<Issue> getRecommendIssues(ArrayList<HistoryList> historyInfoList) {

		// 종가와 시가의 차이가 15% 이상인 종목 선정
		
		// 선정된 종목에 대해  master api를 호출하여 재무정보와 업종 데이터 수신
		// 재무정보를 바탕으로 추천 종목 후보군 선정
		//		String isuSrtCd = arrIssue[0].getIsuSrtCd();
		//		MasterInfo masterInfo = marketDataApiCaller.getMasterInfo(marketCode, isuSrtCd);
		//		listKorAbbrv.add(masterInfo.getIsuKorAbbrv());
				
		//Issue[] arrIssue = issueList.getIsuLists();
		//ArrayList<String> listKorAbbrv = new ArrayList<String>();
		//for(Issue issue : arrIssue) {
		//	String isuSrtCd = issue.getIsuSrtCd();
		//	MasterInfo masterInfo = marketDataApiCaller.getMasterInfo(marketCode, isuSrtCd);
		//	listKorAbbrv.add(masterInfo.getIsuKorAbbrv());
		//}
		
		// 언론 노출 빈도 적용하여 추천 종목 선정
		
		// 업종별로 분류
		
		//// test code
		ArrayList<Issue> recommendIssues = new ArrayList<Issue>();
		for(HistoryList historyInfo : historyInfoList) {
			Issue issue = new Issue();
			issue.setIsuCd(historyInfo.getIsuCd());
			issue.setIsuKorAbbr(historyInfo.getIsuKorAbbr());
			issue.setIsuKorNm(historyInfo.getIsuKorNm());
			issue.setIsuSrtCd(historyInfo.getIsuSrtCd());
			recommendIssues.add(issue);
		}
		
		

		return recommendIssues;
	}

}
